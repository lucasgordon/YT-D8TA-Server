// Configure your import map in config/importmap.rb
import "@hotwired/turbo-rails"
import "./controllers" ;
