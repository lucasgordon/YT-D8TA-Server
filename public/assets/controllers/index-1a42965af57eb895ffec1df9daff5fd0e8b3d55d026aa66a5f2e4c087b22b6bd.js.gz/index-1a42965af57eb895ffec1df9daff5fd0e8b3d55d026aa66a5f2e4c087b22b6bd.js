// Entry point for Stimulus controllers
import { Application } from "@hotwired/stimulus"

window.Stimulus = Application.start() ;
